@echo off
REM ============================================================
REM 时间记录同步到 MySQL（通用多业务线版）
REM 依赖：Python 3.6+（pymysql 已打包进 scripts 目录，无需 pip install）
REM
REM ★ 部署时修改下面 BIZ_LINE 为你的业务线名称（智慧记三子线须用全称）：
REM   效贷 / 泾渭云 / 效融 / 小贷 / 智慧记+运营系统 / AI进销存 / 智慧记零售
REM ============================================================
set BIZ_LINE=智慧记+运营系统

REM ------------------------------------------------------------
REM 定时：每天 12:00 / 18:00 各一次
REM 首次注册计划任务（以管理员身份运行 CMD，执行以下两条）：
REM   schtasks /create /tn "时间同步-午" /tr "%~dp0sync_task.bat" /sc daily /st 12:00 /f
REM   schtasks /create /tn "时间同步-晚" /tr "%~dp0sync_task.bat" /sc daily /st 18:00 /f
REM
REM 查看：   schtasks /query /tn "时间同步-午"
REM 删除：   schtasks /delete /tn "时间同步-午" /f & schtasks /delete /tn "时间同步-晚" /f
REM ------------------------------------------------------------

REM 切换到脚本目录（确保加载同目录打包的 pymysql 和 biz_line_helper）
cd /d "%~dp0"

REM 运行同步，日志追加到本地
python sync_to_mysql.py --biz-line %BIZ_LINE% >> "%~dp0sync_log.txt" 2>&1

exit /b %ERRORLEVEL%
